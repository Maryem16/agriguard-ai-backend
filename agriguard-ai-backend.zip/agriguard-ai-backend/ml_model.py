import random

def predict_carbon():
    return round(random.uniform(1.5, 4.5), 2)